//Created by @AkhilD on 04/01/2021.
package com.app.exception;

@SuppressWarnings("serial")
public class BookShopException extends Exception {

	public BookShopException(String msg) {
		super(msg);

	}

}
