//Created by @AkhilD on 04/01/2021.
package com.app.users;

public enum Type {
	ADMIN, CUSTOMER
}
