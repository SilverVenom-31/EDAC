package p4;

public interface A {
  double data=100;
  void show();
}
