package p4;

public interface B {
  double data=200;
  void show();
}
