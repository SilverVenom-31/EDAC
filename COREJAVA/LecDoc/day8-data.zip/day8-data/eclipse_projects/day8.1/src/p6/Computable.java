package p6;

public interface Computable {
  double PI=3.1414;
  double calcArea();
  double calcPerimeter();
}
