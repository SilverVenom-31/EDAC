package p5;

public interface B {
	boolean test(int data);
}
