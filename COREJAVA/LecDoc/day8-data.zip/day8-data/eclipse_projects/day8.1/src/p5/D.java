package p5;

public class D implements C {

	@Override
	public double calc(double a, double b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean test(int data) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void print(String mesg) {
		// TODO Auto-generated method stub

	}

}
