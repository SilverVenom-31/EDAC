package p5;

public interface A {
  double calc(double a,double b);
}
