package p3;

public interface Printable {
	void print(String message);
}
