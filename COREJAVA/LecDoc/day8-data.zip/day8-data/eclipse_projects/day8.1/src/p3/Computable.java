package p3;

public interface Computable {
	//javac adds : public static final
	double PI=3.1414;
	//javac adds : public abstract
	double compute(double a,double b);

}
