package p2;

public  class Multiplier implements Computable{
	@Override
	public double compute(double a,double b)
	{
		return a*b;
	}

}
