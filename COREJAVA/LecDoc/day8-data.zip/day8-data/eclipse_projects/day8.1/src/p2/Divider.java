package p2;

public  class Divider implements Computable{
	@Override
	public double compute(double a,double b)
	{
		return a/b;
	}

}
