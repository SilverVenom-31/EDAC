package p2;

public  class Adder implements Computable{
	@Override
	public double compute(double a,double b)
	{
		return a+b;
	}

}
