package com.core.type;

public class Program1
{
	public static void main(String[] args)
	{
		boolean success = true;
		System.out.println("Success	:	"+success);
		
		byte num1 = 125;
		System.out.println("Num1	:	"+num1);
		
		short num2 = 1250;
		System.out.println("Num2	:	"+num2);
		
		char ch ='S';
		System.out.println("Ch	:	"+ch);
		
		int num3 = 123456;
		System.out.println("Num3	:	"+num3);
		
		long num4 = 123456789;
		System.out.println("Num4	:	"+num4);
		
		float num5 = 123.45f;
		System.out.println("Num5	:	"+num5);
		
		double num6 = 12345.67;
		System.out.println("Num6	:	"+num6);
	}
}
