package com.app.core;

public enum Subject {
	JAVA, R, ML, CLOUD, PYTHON, DBT
}
