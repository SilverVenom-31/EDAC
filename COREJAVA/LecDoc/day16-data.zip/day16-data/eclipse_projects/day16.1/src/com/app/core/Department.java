package com.app.core;

public enum Department {
	RND, HR, FINANCE, PRODUCTION
}
