package custom_exceptions;

public class EmpHandlingException extends Exception {
public EmpHandlingException(String mesg) {
	super(mesg);
}
}
