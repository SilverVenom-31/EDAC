package p1;

public class Tester {

	public static void main(String[] args) {
		C ref=new C();//heap : 1 object

	}

}
