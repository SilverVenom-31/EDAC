package p1;

public class B extends A {
	public B() {
		//super()
		System.out.println("2");
	}
}
