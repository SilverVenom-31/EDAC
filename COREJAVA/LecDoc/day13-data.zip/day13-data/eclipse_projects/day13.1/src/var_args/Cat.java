package var_args;

public class Cat extends Animal {
	public Cat() {
		super("Cat");
	}

}
