package non_generics;

public class Holder {
	private Object ref;//HAS-A 

	public Holder(Object ref) {
		super();
		this.ref = ref;
	}

	public  Object getRef() {
		return ref;
	}
	

}
