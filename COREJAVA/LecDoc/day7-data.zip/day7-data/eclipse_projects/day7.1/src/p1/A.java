package p1;

public class A {
	public A() {
		//super() : obj's constr
		System.out.println("1");
	}

}
