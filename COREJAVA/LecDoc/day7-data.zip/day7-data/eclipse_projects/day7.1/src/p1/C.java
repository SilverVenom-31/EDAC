package p1;

public class C extends B {
	public C() {
		//super() : added implicitly by javac
		System.out.println("3");
	}
}
