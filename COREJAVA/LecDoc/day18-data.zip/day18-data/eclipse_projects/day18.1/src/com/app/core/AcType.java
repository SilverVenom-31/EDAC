package com.app.core;

public enum AcType {
	SAVING, CURRENT, FD, LOAN, DMAT
}
