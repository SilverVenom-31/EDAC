//Created by @AkhilD on 17/01/2021.
package com.app.exception;


@SuppressWarnings("serial")
public class BuddyExceptionHandling extends Exception {

	
	public BuddyExceptionHandling(String arg0) {
		super(arg0);
		
	}

	

}
