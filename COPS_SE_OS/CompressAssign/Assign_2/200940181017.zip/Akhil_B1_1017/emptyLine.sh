#!/bin/bash
##Created by @AkhilDarge on 23/10/20.

##Q12.Create a script to remove all empty lines from a file.

read -p "Enter a file: " file
emp=$(sed '/^$/d' $file)
echo "$emp" > "$file"

