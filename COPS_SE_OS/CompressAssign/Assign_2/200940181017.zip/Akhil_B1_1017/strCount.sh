#!/bin/bash
## Created by @AkhilDarge on 24/10/20.

##Q11. Create a shell program to count number of words, characters, white spaces and special symbols in a given text.

read -p "Enter a String: " str

word=$(echo "$str" | wc -w)
echo "Word count: $word"

char=$(echo "$str" | wc -m)
char=`expr $char - 1`
echo "Character count: $char"

space=$(echo "$str" | tr -cd ' \t' | wc -c)
echo "Space count: $space"

specials=$(echo "$str" | tr -cd '[:punct:]' | wc -c)
echo "Special symbols count: $specials"
