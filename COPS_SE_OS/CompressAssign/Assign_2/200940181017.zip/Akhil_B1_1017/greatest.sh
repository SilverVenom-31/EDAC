#!/bin/bash
##Created by @AkhilDarge on 23/10/20.

##Q9. Create a shell script to find the largest among the 3 given numbers.

read -p "Enter number1 : " num1

read -p "Enter number2 : " num2

read -p "Enter number3 : " num3

if [ $num1 -gt $num2 ]; then
	if [ $num1 -gt $num3 ]; then
		echo "$num1 is greatest"
	else
		echo "$num3 is greatest"
	fi
elif [ $num1 -gt $num3 ]; then
	echo "$num2 is greatest"

elif [ $num2 -gt $num3 ]; then
	echo "$num2 is greatest"
else
	echo "$num3 is greatest"
fi
