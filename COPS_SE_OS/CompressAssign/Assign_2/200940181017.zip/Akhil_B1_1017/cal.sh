#!/bin/bash
##Created by @AkhilDarge on 23/10/20.

##Q4. Create a calculator program in bash that takes two numbers (integers) and display menu to the user for various mathematical operations. Hint: Switch Case Break.

read -p "Enter number1: " num1
read -p "Enter number2: " num2

echo "Select operation to perform: "
read -p "+, -, *, / :" operation

case $operation in
"+")
	add=$(expr $num1 + $num2)
	echo "Addition: $add"
	;;
"-")
	sub=$(expr $num1 - $num2)
	echo "Subtraction: $sub"
	;;
"*")
	mul=$(expr $num1 \* $num2)
	echo "Multiplication: $mul"
	;;
"/")
	div=$(expr $num1 / $num2)
	echo "Division: $div"
	;;
esac
