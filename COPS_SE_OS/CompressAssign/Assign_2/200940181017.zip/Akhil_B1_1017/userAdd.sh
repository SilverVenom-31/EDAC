#!/bin/bash
## Created by @AkhilDarge on 23/10/20.

##Q3. Create a script that asks for a user name and add that user with password same as that of user name. The user added should be assigned nologin shell.

read -p "Enter username: " username
useradd -m $username -p $username -s /sbin/nologin
