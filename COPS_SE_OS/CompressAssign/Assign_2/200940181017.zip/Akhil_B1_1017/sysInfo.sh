#!/bin/bash
##Created by @AkhilDarge on 23/10/20.

##Q8. Create a script that displays the system information like: OS name, kernel version, RAM, etc..

echo "Kernel Name: $(uname)"

echo "Network hostname: $(uname -n)"

echo "Kernel Version: $(uname -v)"

echo "Kernel Release: $(uname -r)"

echo "Machine Hardware Name: $(uname -m)"

echo "Memory usage Statistics: $(vmstat -s)"
