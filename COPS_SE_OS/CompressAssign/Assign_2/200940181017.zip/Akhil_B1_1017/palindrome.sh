#!/bin/bash
##Created by @AkhilDarge on 23/10/20.

##Q10. Create a shell program to check whether a given string is palindrome.

read -p "Enter a string: " str

rts=$(echo $str | rev)

if [ $str == $rts ]; then
	echo "String is pallindrome"
else
	echo "String is not pallindrome"
fi
