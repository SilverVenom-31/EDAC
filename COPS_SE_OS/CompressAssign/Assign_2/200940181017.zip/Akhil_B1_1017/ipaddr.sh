#!/bin/bash
##Created by @AkhilDarge on 23/10/20.

##Q13. Create a script that fetches only the IP address of the machine from output of ifconfig command.

check=$(nmcli | grep -w "connected")
if [ "$check" ]
then

	interface=$( echo "$check" | cut -d':' -f1 | head -n 1)
	ifconfig >/tmp/ipaddr

	line=$(grep -rino $interface /tmp/ipaddr | head -n 1 | cut -d':' -f1)
	imp=$(expr $line + 1)
	awk "NR>=$line && NR<=$imp" /tmp/ipaddr | sed -n 2p | awk -F' ' '{print $2}'

else

	echo "Please connect to internet"
fi
