#!/bin/bash
## Created by @AkhilDarge on 23/10/20.

##Q14. Create a script that asks for repo name and creates a repository on github with that name.

read -p "Enter username: " username
read -p "Enter repository name: " repo_name

curl -u "$username" https://api.github.com/user/repos -d "{\"name\":\"$repo_name\"}" >/tmp/githubData

echo "git url: "
echo "https://github.com/$username/$repo_name.git"
