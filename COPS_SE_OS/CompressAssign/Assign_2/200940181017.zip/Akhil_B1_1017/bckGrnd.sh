#!/bin/bash
##Created by @AkhilDarge on 23/10/20.

##Q7. Create a script that depicts sending the process to background so that the next command in sequence can run without wait.

mkdir test
cd test
touch testfile
sleep 100 &
echo "Hello Friend" >testfile
cat testfile

ps -elf | grep --color=auto "sleep 100"
