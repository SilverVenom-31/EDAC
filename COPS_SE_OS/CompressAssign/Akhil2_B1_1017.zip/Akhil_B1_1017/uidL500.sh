#!/bin/bash
##Created by @AkhilDarge on 16/10/20.

cat /etc/passwd | cut -d':' -f3 > uidL500data

while read line
do
  if [ "$line" -lt 500 ]
  then
    username=$(cat /etc/passwd | grep -w "$line" | cut -d':' -f1)
    shell=$(cat /etc/passwd | grep -w "$line" | cut -d':' -f7)
    echo ""$username" >>>>>> "$shell""
  fi

done < uidL500data

rm -rf uidL500data

