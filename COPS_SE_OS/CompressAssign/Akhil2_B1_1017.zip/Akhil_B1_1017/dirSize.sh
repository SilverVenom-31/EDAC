#!/bin/bash
##Created by @AkhilDarge on 16/10/20.

read -p "Enter directory name: " dir

du -sh "$dir" | awk -F' ' '{print $1}'

