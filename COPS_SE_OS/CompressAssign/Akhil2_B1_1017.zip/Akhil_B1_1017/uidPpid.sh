#!/bin/bash
##Created by @AkhilDarge on 16/10/20.

read -p "Enter process name: " process

ps -elf | grep -w "$process" | awk -F' ' '{print $3,$4,$5}'
