#!/bin/bash
##Created by @AkhilDarge on 16/10/20.

read -p "Enter file name: " fileName

stat -c %a "$fileName"
