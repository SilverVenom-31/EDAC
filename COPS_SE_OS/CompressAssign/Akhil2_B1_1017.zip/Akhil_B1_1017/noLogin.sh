#!/bin/bash
##Created by @AkhilDarge on 16/10/20.


cat /etc/passwd | grep "/sbin/nologin" | awk -F':' '{print $1}'

