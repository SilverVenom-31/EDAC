#!/bin/bash
##Created by @AkhilDarge on 15/10/20.

read -p "Enter username: " user
cat /etc/passwd | grep -E "(bash|sh|zsh|tcsh|ksh)" | grep -v "root" | awk -F':' '{print $1}' > /tmp/data

while read line
do
  cat /etc/shadow | grep "$line" |grep "\!\!" | awk -F':' '{print $1}' >> /tmp/data2

done </tmp/data

if grep -q $user /tmp/data
then
  cat /etc/passwd | grep $user
  if grep -q $user /tmp/data2
  then
    echo "$user password has not set"
  else
    echo "$user password is set"
fi
else
  echo "User does not exists"

fi

