#!/bin/bash
##Created by @AkhilDarge on 16/10/20.

read -p "Enter Username: " name
read -sp "Enter Password for "$name": " pass

useradd "$name"
echo "$pass" | passwd --stdin "$name"



