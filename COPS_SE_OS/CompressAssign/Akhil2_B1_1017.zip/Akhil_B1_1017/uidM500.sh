#!/bin/bash
##Created by @AkhilDarge on 16/10/20.

cat /etc/passwd | cut -d':' -f3 > uidM500data

while read line
do
  if [ "$line" -gt 500 ]
  then
    cat /etc/passwd | grep -w "$line" | cut -d':' -f1,3
  fi
  
done < uidM500data

rm -rf uidM500data


