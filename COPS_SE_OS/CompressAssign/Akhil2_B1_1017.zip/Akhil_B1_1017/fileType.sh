#!/bin/bash
##Created by @AkhilDarge on 16/10/20.

read -p "Enter file: " file

fileType=$(file "$file" | awk -F':' '{print $2}')

echo ""$file" >>>>>"$fileType""

