//Created by @AkhilDarge on 11/10/20

import java.util.Scanner;

public class PatternTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter any number: ");
        int inp = sc.nextInt();
        Pattern pt = new Pattern(inp);
        pt.displayPattern();
        sc.close();
    }
}
