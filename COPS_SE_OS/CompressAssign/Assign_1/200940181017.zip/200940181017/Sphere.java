//Created by @AkhilDarge on 11/10/20

class Sphere {
    private final double radius;

    public Sphere(double radius) {
        this.radius = radius;
    }

    public double surfaceArea() {
        return 4 * Math.PI * radius * radius;
    }

    public double volume() {
        return (4 / 3f) * Math.PI * radius * radius * radius;
    }

}
