//Created by @AkhilDarge on 11/10/20

import java.util.Scanner;

public class SphereTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter radius of Sphere: ");
        double inp = sc.nextDouble();
        Sphere sph = new Sphere(inp);
        System.out.println("Surface Area of Sphere: " + sph.surfaceArea());
        System.out.println("Volume of Sphere: " + sph.volume());
        sc.close();
    }
}
