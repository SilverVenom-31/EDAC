//Created by @AkhilDarge on 11/10/20

import java.util.Scanner;

public class ArrayCheckTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter length of Arrays: ");
        int len = sc.nextInt();
        int[] arr1 = new int[len];
        int[] arr2 = new int[len];

        System.out.println("Enter elements of array 1:");  //populating array1
        for (int i = 0; i < arr1.length; i++) {
            arr1[i] = sc.nextInt();
        }
        System.out.println("Enter elements of array 2:");  //populating array2
        for (int i = 0; i < arr2.length; i++) {
            arr2[i] = sc.nextInt();
        }
        ArrayCheck arc = new ArrayCheck(arr1, arr2);
        if (!arc.isArrayEqual()) {                      //return true if equal arrays
            System.out.println("Array is not equal");
        } else {
            System.out.println("Array is equal");
        }
        sc.close();
    }
}
