//Created by @AkhilDarge on 11/10/20

public class Pattern {
    private int n;

    public Pattern(int n) {
        this.n = n;
    }

    public void displayPattern() {
        int[] arr = new int[n];
        int count = n;
        for (int j = 0; j < count; j++) { //outer loop is for rows
            for (int i = 0; i < n; i++) {
                arr[i] = i + 1;
            }
            for (int i = 0; i < n; i++) {
                System.out.print(arr[i]);
            }
            System.out.println();
            n--;
        }
    }


}

