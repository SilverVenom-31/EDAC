//Created by @AkhilDarge on 11/10/20
public class ArrayCheck {
    private final int[] arr1;
    private final int[] arr2;

    public ArrayCheck(int[] arr1, int[] arr2) {

        this.arr1 = arr1;
        this.arr2 = arr2;
    }

    public boolean isArrayEqual() {

        int count = 0;
        for (int i = 0; i < arr1.length; i++) {
            if (arr1[i] == arr2[i]) {
                count++;
            }
        }
        //returns true if array are equal
        return count == arr1.length;

    }
}
