#!/bin/bash


echo "Date and Time: "
date
echo "Username: "
whoami
echo "Current working directory: "
pwd

