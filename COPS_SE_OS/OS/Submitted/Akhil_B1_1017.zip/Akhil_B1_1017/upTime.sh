#!/bin/bash


echo "System running time: "
uptime -p
