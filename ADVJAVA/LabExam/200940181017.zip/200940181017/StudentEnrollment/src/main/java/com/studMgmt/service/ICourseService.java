//Created by @AkhilD on 22/02/2021
package com.studMgmt.service;

import java.util.List;

import com.studMgmt.pojos.Courses;

public interface ICourseService {
	List<Courses> listCourses();
	String deleteCourse(int id);
}
