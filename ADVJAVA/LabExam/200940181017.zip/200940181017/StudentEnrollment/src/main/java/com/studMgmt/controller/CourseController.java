//Created by @AkhilD on 22/02/2021
package com.studMgmt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.studMgmt.service.CourseServices;

@Controller
@RequestMapping("/course")
public class CourseController {
	@Autowired
	private CourseServices courseServices;

	@GetMapping("/course")
	public String showCourseList(Model map) {
		map.addAttribute("listCourse", courseServices.listCourses());
		return "/course/course";
	}

	@GetMapping("/delete")
	public String deleteCourse(@RequestParam int cid, RedirectAttributes flashMap) {
		flashMap.addFlashAttribute("msg", courseServices.deleteCourse(cid));
		return "redirect:/course/course";
	}

}
