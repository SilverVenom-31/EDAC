//Created by @AkhilD on 22/02/2021
package com.studMgmt.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.studMgmt.pojos.Courses;
import com.studMgmt.pojos.Students;

@Repository
public class StudentDaoImpl implements IStudentDao {
	@Autowired
	private EntityManager mgr;

	@Override
	public String enrollStudent(int id, Students stud) {
		Courses c = mgr.find(Courses.class, id);
		if (c != null) {
			stud.setCourse(c);
			mgr.persist(stud);
		}
		return "Student Registered Successfully";
	}

	

}
