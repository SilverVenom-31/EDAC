//Created by @AkhilD on 22/02/2021
package com.studMgmt.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "courses")
public class Courses extends BaseEntity{
@Column(length = 20)
	private String name;
	 
@OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
private List<Students> students = new ArrayList<>();


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public List<Students> getStudents() {
	return students;
}


public void setStudents(List<Students> students) {
	this.students = students;
}
	
	
}
