//Created by @AkhilD on 22/02/2021
package com.studMgmt.service;

import com.studMgmt.pojos.Students;

public interface IStudentService {
	String enrollStudent(int id,Students stud);
	
}
