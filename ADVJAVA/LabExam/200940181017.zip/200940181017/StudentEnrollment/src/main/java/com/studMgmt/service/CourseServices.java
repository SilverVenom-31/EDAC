//Created by @AkhilD on 22/02/2021
package com.studMgmt.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studMgmt.dao.CourseDaoImpl;
import com.studMgmt.pojos.Courses;

@Service
@Transactional
public class CourseServices implements ICourseService {
	@Autowired
	private CourseDaoImpl cDao;

	@Override
	public List<Courses> listCourses() {

		return cDao.listCourses();
	}

	@Override
	public String deleteCourse(int id) {
		
		return cDao.deleteCourse(id);
	}

}
