//Created by @AkhilD on 22/02/2021
package com.studMgmt.dao;

import java.util.List;

import com.studMgmt.pojos.Courses;

public interface ICoursesDao {

	List<Courses> listCourses();
	
	String deleteCourse(int id);
	
}
