//Created by @AkhilD on 22/02/2021
package com.studMgmt.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studMgmt.dao.StudentDaoImpl;
import com.studMgmt.pojos.Students;
@Service
@Transactional
public class StudentServiceImpl implements IStudentService {

	@Autowired 
	private StudentDaoImpl sDao;
	@Override
	public String enrollStudent(int id, Students stud) {
		
		return sDao.enrollStudent(id, stud);
	}
	

}
