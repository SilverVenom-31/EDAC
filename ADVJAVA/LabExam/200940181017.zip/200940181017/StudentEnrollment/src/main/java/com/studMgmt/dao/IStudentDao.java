//Created by @AkhilD on 22/02/2021
package com.studMgmt.dao;

import com.studMgmt.pojos.Students;

public interface IStudentDao {

	String enrollStudent(int id,Students stud);
	
	
}
