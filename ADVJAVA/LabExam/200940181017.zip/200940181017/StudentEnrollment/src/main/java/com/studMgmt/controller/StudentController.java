//Created by @AkhilD on 22/02/2021
package com.studMgmt.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.studMgmt.pojos.Students;
import com.studMgmt.service.StudentServiceImpl;

@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentServiceImpl studentService;

	@GetMapping("/register")
	public String showRegForm(Students stud, @RequestParam int cid, Model map, HttpSession hs) {
		hs.setAttribute("cid", cid);
		return "/student/register";

	}

	@PostMapping("/register")
	public String proccessStudReg(@Valid Students stud, BindingResult bs, RedirectAttributes flashMap, HttpSession hs,Model map) {

		int cid = (int) hs.getAttribute("cid");
		
		if(stud.getCgpa()<8) {
			map.addAttribute("error1", "cgpa should be greater than 7");
			return "/student/register";
		}
		if(stud.getDobDate().getYear()<1991) {
			map.addAttribute("error2", "Dob should be after 1990");
			return "/student/register";
		}

		flashMap.addFlashAttribute("msg", studentService.enrollStudent(cid, stud));
		hs.invalidate();
		return "redirect:/course/course";
	}

}
