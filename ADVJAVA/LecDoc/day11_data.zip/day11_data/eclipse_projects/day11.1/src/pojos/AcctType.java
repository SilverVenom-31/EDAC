package pojos;

public enum AcctType {
	SAVING, CURRENT, FD, LOAN
}
