package pojos;

public enum PaymentMode {
GPAY,PAYTM,NETBANKING,DEBIT_CARD
}
