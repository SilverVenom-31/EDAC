package dao;

import java.sql.*;
import static utils.DBUtils.fetchDBConnection;

public class AccountDaoImpl implements IAccountDao {
	private Connection cn;
	private CallableStatement cst1;

	public AccountDaoImpl() throws ClassNotFoundException, SQLException {
		// get cn from DBUtils
		cn = fetchDBConnection();
		// {call <procedure-name>[(<arg1>,<arg2>, ...)]}
		// Method of Connection i/f
		// public CallableStatement prepareCall(String invocationSyntax)
		// # 1
		cst1 = cn.prepareCall("{call transfer_funds(?,?,?,?,?)}");
		// #2 register OUT param/s : To inform JVM about JDBC data types of OUT / IN OUT
		// params
		cst1.registerOutParameter(4, Types.DOUBLE);
		cst1.registerOutParameter(5, Types.DOUBLE);
		System.out.println("acct dao created...");

	}

	@Override
	public String transferFunds(int srcId, int destId, double amount) throws SQLException {
		// set IN params : API inherited from PST
		cst1.setInt(1, srcId);
		cst1.setInt(2, destId);
		cst1.setDouble(3, amount);
		//execute stored procedure
		cst1.execute();		
		return "Updated src balance "+cst1.getDouble(4)+" dest balance "+cst1.getDouble(5);
	}
	//clean up
	public void cleanUp() throws SQLException
	{
		if(cst1 != null)
			cst1.close();
		if(cn != null)
			cn.close();
	}

}
