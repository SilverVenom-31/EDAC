function exec() {
    let email = document.getElementById("e1").value;
    let conEmail = document.getElementById("e2").value;

    if (email != conEmail) {
        alert("Email ID and Confirm Email Id field values have to be same.");

    } else {
        alert("All data entered correctly");
    }

}



function auth() {
    let stand = document.getElementById("s1").value;

    if (stand == "PlatinumGallery") {
        document.getElementById("s2").selectedIndex = "3";
        document.getElementById("t2").value = 25000;
        document.getElementById("s2").options[1].disabled = true;
        document.getElementById("s2").options[2].disabled = true;
        document.getElementById("s2").options[3].disabled = false;





    } else if (stand == "SuperHospitalityStand") {
        document.getElementById("s2").selectedIndex = "3";
        document.getElementById("t2").value = 20000;
        document.getElementById("s2").options[1].disabled = true;
        document.getElementById("s2").options[2].disabled = true;
        document.getElementById("s2").options[3].disabled = false;



    } else {
        document.getElementById("s2").selectedIndex = "0";
        document.getElementById("t2").value = " ";
        document.getElementById("s2").options[1].disabled = false;
        document.getElementById("s2").options[2].disabled = false;
        document.getElementById("s2").options[3].disabled = true;



    }

}

function trace() {
    let stand = document.getElementById("s1").value;
    let floor = document.getElementById("s2").value;

    switch (floor) {

        case "firstFloor":
            switch (stand) {
                case "NorthWestStand":
                    document.getElementById("t2").value = 6000;
                    break;
                case "EastStand":
                    document.getElementById("t2").value = 3000;
                    break;
                default:
                    alert("Sorry for inconvenience, Please reload the page");

            }
            break;

        case "secondFloor":

            switch (stand) {
                case "NorthWestStand":
                    document.getElementById("t2").value = 2000;
                    break;
                case "EastStand":
                    document.getElementById("t2").value = 1000;
                    break;
                default:
                    alert("Sorry for inconvenience, Please reload the page");

            }
            break;

        default:
            alert("Sorry for inconvenience, Please reload the page");

    }

}